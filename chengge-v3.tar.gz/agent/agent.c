/*
 * agent program running on devices.
 *
 * 1. 先于manager程序运行
 * 2. 监听UDP端口 AGENT_LISTEN_UDP_BCAST_PORT，广播模式
 * 3. 接收来自manager的udp广播包，设备发现报文
 * 4. 回送udp报文，内含tcp连接参数，例如端口号
 * 5. 建立本地tcp监听，等待manager发起tcp连接
 * 6. manager发起tcp连接到达，建立连接
 * 7. 等待manager发送控制指令.
 */
#include<stdio.h>
#include<string.h>
#include<errno.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
#include<sys/wait.h>
#include<arpa/inet.h>
#include"jdcjson.h"
#include <string.h>
#include <time.h>
#include <stdio.h>

/*
 * 现在的设计是不支持多个agents运行的。原因如下：
 * 1）agent发送tcp连接参数到manager
 * 2）manager接收到连接参数之后，在manager端设置监听
 * 因为现在所有的agent发送的连接参数都是完全相同的，端口信息均为3084，2）中设
 * 置tcp监听端口时，只有第一个可以成功，后续的会失效。所有的agent后续向3084发
 * 情连接请求时，只有第一个agent可以正常连接，后续的agents都会连接失败。
 * 所以是不支持多个连接的。
 *
 * 修改方法：
 * 1）agent发送tcp连接参数，发送不同的端口信息到manager，例如分别发送3084\3085
 * \3086……
 * 2）agent发送tcp连接参数到manager，但是在agent端建立tcp监听，agent根据接收到
 * 的tcp连接参数，主动发起通向manager的tcp连接
 * 比较一下发现，修改方法2）才是正确的，因为agent根本就无法获知发送什么样的
 * port信息才不会与其他agent重复
 */

// agent监听3083端口，接收来自manager的搜索发现udp包
#define AGENT_LISTEN_UDP_BCAST_PORT 3083
int AGENT_UDP_PORT = -1;
// agent监听3084端口，接收来自manager的控制命令
#define AGENT_LISTEN_TCP_CMD_PORT 3084

struct sockaddr_in addr_local_udp;				// 本地地址udp
struct sockaddr_in addr_local_tcp;				// 本地地址tcp
struct sockaddr_in addr_manager_udp;			// 管理站地址

char recv_buf[500];								// 接收缓存
char send_buf[500];								// 发送缓存

int code1;
float code2;
char *name;

// 从地址结构体中提取ip地址
char * getip(struct sockaddr_in sock_in) {
	char * ip = (char *)malloc(sizeof(char)*16);
	memset(ip, 0, strlen(ip));
	sprintf(ip, "%d.%d.%d.%d\n", 
		(int)(sock_in.sin_addr.s_addr & 0xFF), 
		(int)((sock_in.sin_addr.s_addr & 0xFF00) >> 8), 
		(int)((sock_in.sin_addr.s_addr & 0xFF0000) >> 16), 
		(int)((sock_in.sin_addr.s_addr & 0xFF000000) >> 24));
	return ip;
}

// 大端到小端
unsigned int BigtoLittle32(unsigned int A)
{
	unsigned int a, b, c, d, e;
	a = (A & 0xff000000) >> 24;
	b = (A & 0x00ff0000) >> 8;
	c = ((A) & 0x0000ff00) << 8;
	d = ((A) & 0x000000ff) << 24;
	e = a | b | c | d;
	return e;
}

// 小端到大端
unsigned int LittletoBig32(unsigned int A)
{
	unsigned int a, b, c, d, e;
	a = (A & 0x000000ff) << 24;
	b = (A & 0x0000ff00) << 8;
	c = ((A) & 0x00ff0000) >> 8;
	d = ((A) & 0xff000000) >> 24;
	e = a | b | c | d;
	return e;
}

// 数据包的处理，包括组包和解包     
typedef struct
{
	unsigned int magic_a;
	unsigned int magic_b;
	unsigned int checksum;
	unsigned int len;
} common_header;

/**
 * UDP\TCP组包
 *
 * @param pBuf 将组装后的udp/tcp数据存储到pBuf中
 * @param root json根节点
 * @udp_tcp 指定协议类型
 *
 * @return 返回组装后的数据包的字节数量
 */
static int PacketBuild(char *pBuf, cJSON * root, char udp_tcp)
{
	int head = ((udp_tcp == 'U') ? 0x00000055 : 0x00000056);

	common_header *pCommon = (common_header *) pBuf;
	pCommon->magic_a = LittletoBig32(head);
	pCommon->magic_b = LittletoBig32(head);

	char *pData = pBuf + 16;
	char *psJson = cJSON_PrintUnformatted(root);
	int length = strlen(psJson);

	memcpy(pData, psJson, length);
	free(psJson);
	pCommon->len = LittletoBig32(length+16);

	int i = 0;
	char sum = 0;
	for (i = 0; i < (length + 16); i++)
		sum += *(pBuf + i);

	pCommon->checksum = LittletoBig32(sum);

	return length + 16;
}

/**
 * 将数据解析成JSON数据
 *
 * @param pBuf 待解析的数据地址
 * @return 返回生成的JSON数据的根root
 */
static cJSON *PacketAnalyse(char *pBuf)
{
	common_header *pCommon = (common_header *) pBuf;

	pCommon->magic_a = BigtoLittle32(pCommon->magic_a);
	pCommon->magic_b = BigtoLittle32(pCommon->magic_b);
	pCommon->len = BigtoLittle32(pCommon->len);
		
	cJSON *pRet = cJSON_Parse(pBuf + 16);
	return pRet;
}

/**
 * 处理manager发送的tcp控制命令报文
 *
 * @param conn_fd 连接socket fd
 */
void process_tcp_packets(int conn_fd)
{
	int send_num, recv_num;
	char recv_buf[500] = {0};
	char send_buf[500] = {0};

	int cmd, per, codea;
	float codeb;
	char *codec;

	printf("开始接收manager发送的tcp控制命令:\n");
	recv_num = recv(conn_fd, recv_buf, sizeof(recv_buf), 0);
	if (recv_num < 0)
	{
		perror("接收tcp控制命令失败");
		exit(1);
	}
	else
	{
		printf("接收tcp控制命令成功:\n");

		cJSON *stroot = PacketAnalyse(recv_buf);
		cmd = cJSON_GetObjectItem(stroot, "cmd")->valueint;
		per = cJSON_GetObjectItem(stroot, "per")->valueint;

		// per==1表示当前tcp包为权限设置，per!=1表示为命令设置
		if (per == 1)
		{

			switch (cmd)
			{
			  case 1:
				  codea = cJSON_GetObjectItem(stroot, "code")->valueint;
				  printf("cmd:%d  per:%d   code:%d\n", cmd, per, codea);
				  code1 = codea;
				  break;
			  case 2:
				  codeb = cJSON_GetObjectItem(stroot, "code")->valuedouble;
				  printf("cmd:%d per:%d   code:%f\n", cmd, per, codeb);
				  code2 = codeb;
				  break;
			  case 4:
				  codec = cJSON_GetObjectItem(stroot, "code")->valuestring;
				  printf("cmd:%d  per:%d   code:%s\n", cmd, per, codec);
				  name = codec;
				  break;
			default:
				  break;
			}
		}
		else
		{
			printf("cmd:%d  per:%d \n", cmd, per);
		}
	}

	printf("对manager发送的tcp控制命令做出响应\n");

	cJSON *ctroot = cJSON_CreateObject();
	if (ctroot == NULL) {
		perror("cJSON create failed");
		exit(-1);
	}

	//组数据包  
	cJSON_AddNumberToObject(ctroot, "cmd", cmd);	//添加字符串
	switch (cmd)
	{
	  case 1:
		  cJSON_AddNumberToObject(ctroot, "code", code1);	//添加字符串
		  break;
	  case 2:
		  cJSON_AddNumberToObject(ctroot, "code", code2);
		  break;
	  case 4:
		  cJSON_AddStringToObject(ctroot, "code", name);
		  break;
	  case 3:
		  cJSON_AddStringToObject(ctroot, "code", "0000001a");
		  break;
	  default:
		  break;
	}

	int data_len = PacketBuild(send_buf, ctroot, 'T');

	send_num = send(conn_fd, send_buf, data_len, 0);
	if (send_num < 0)
	{
		perror("发送控制命令的响应，发送失败");
		exit(-1);
	}
	else
	{
		printf("发送控制命令的响应，发送成功\n");

		int m=0;
		for(;m<data_len;m++)
			printf("%x",send_buf[m]);
		printf("\n");
	}
}

/**
 *
 * agent设置tcp监听，用于等待manager建立tcp连接
 *
 * @param addr_local_tcp agent监听本地tcp端口
 */
void setup_tcp_listen(struct sockaddr_in addr_local_tcp)
{
	int listen_fd = socket(AF_INET, SOCK_STREAM, 0);
	if (listen_fd < 0)
	{
		perror("申请tcp socket失败");
		exit(1);
	}
	else
		printf("申请tcp socket成功\n");

	// 将socketb绑定到指定地址
	if (bind(listen_fd, (struct sockaddr *)&addr_local_tcp, sizeof(struct sockaddr_in)) < 0)
	{
		perror("tcp端口绑定地址失败");
		exit(1);
	}
	else
		printf("tcp端口绑定地址成功\n");

	if (listen(listen_fd, 100) < 0)
	{
		perror("tcp端口监听失败");
		exit(1);
	}
	else
		printf("tcp端口监听成功\n");

	// 后续处理
	printf("等待tcp连接请求到达\n");
	int conn_fd = accept(listen_fd, NULL, 0);
	printf("manager发起了tcp连接请求，请求已到达\n");
	
	if (conn_fd < 0)
	{
		perror("接受manager连接请求失败");
		exit(-1);
	}
	else
		printf("接受manager连接请求成功\n");

	// agent创建子进程对专门响应manager发送的控制命令
	pid_t pid = fork();
	if (pid == 0)
	{
		while (1)
		{
			process_tcp_packets(conn_fd);
			sleep(1);
		}
	}
	else {
		// 奇葩，父子进程应该独立的，现在父进程结束子进程怎么也结束了?
		// 加个waitpid吧！
		waitpid(pid, NULL, 0);
	}
}

/**
 * 响应管理站udp设备发现请求，回送tcp连接参数
 *
 * @param listen_fd
 * @param send_buf
 * @param dest_len
 */
void send_tcp_params(int listen_fd, char send_buf[], int dest_len)
{
	int send_num;
	char input[100];

	printf("是否接受管理站控制(输入[yes] 或 [no]):\n");
	scanf("%s", input);
	if (strcmp(input, "yes") == 0)
	{
		cJSON *root = cJSON_CreateObject();
		if (root == NULL)
			printf("cJSON create failed\n");
		else
		{
			// 发送tcp连接参数，manager借此参数连接到当前agent
			cJSON_AddNumberToObject(root, "port", AGENT_LISTEN_TCP_CMD_PORT);
			cJSON_AddNumberToObject(root, "IDlen", 8);
			cJSON_AddStringToObject(root, "ID", "0000001a");

			int data_len = PacketBuild(send_buf, root, 'U');

			// 首先，建立本地tcp监听，然后发送tcp连接参数到manager
			addr_local_tcp.sin_family = AF_INET;
			addr_local_tcp.sin_addr.s_addr = addr_local_udp.sin_addr.s_addr;
			addr_local_tcp.sin_port = htons(AGENT_LISTEN_TCP_CMD_PORT);

			// 发送数据
			int bytes_sent = sendto(listen_fd, send_buf, data_len, 0, 
					(struct sockaddr *)&addr_manager_udp, dest_len);

			if (bytes_sent < 0)
			{
				perror("发送tcp连接参数失败");
				exit(1);
			}
			else
				printf("发送tcp连接参数成功\n");

			// 监听
			setup_tcp_listen(addr_local_tcp);
		}
	}
	else {
		printf("正在结束程序...\n");
		exit(0);
	}
}


/**
 * 接受manager发送的udp设备发现报文，并予以处理
 *
 * @param dest_len 目的地址结构体长度
 */
void process_broadcast(int dest_len)
{
	// 申请udp socket
	int listen_fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (listen_fd < 0)
	{
		perror("申请udp socket失败");
		exit(1);
	}
	else
	{
		printf("申请udp socket成功\n");
	}

	// 激活udp socket的广播模式
	int set = 1;
	int nb = setsockopt(
			listen_fd, SOL_SOCKET, SO_BROADCAST, &set, sizeof(int));
	if (nb < 0)
	{
		perror("激活udp socket广播模式失败");
		exit(1);
	}
	else
		printf("激活udp socket广播模式成功\n");

	// 将udp socket(广播模式)绑定到指定地址addr_local_udp
	if (bind(listen_fd, (struct sockaddr *)&addr_local_udp, sizeof(struct sockaddr_in)) < 0)
	{
		perror("udp socket绑定地址失败");
		exit(1);
	}
	else
		printf("udp socket绑定地址成功\n");

	// 接收manager发送的udp设备发现报文，并将manager地址记录到addr_manager_udp
	int len = sizeof(struct sockaddr_in);
	char recv_buf[100] = { 0 };
	int bytes_recved = recvfrom(
			listen_fd, recv_buf, sizeof(recv_buf), 0, 
			(struct sockaddr *)&addr_manager_udp, &len);

	if (bytes_recved < 0)
	{
		perror("接收manager发送的udp设备发现报文，失败");
		exit(1);
	}
	else
	{
		printf("\n接收manager发送的udp设备发现报文，成功\n");

		int s;
		for (s = 0; s < 100; s++) {
			printf("%x ", recv_buf[s]);
		}

		printf("manager ip:%s  port:%d\n", 
				inet_ntoa(addr_manager_udp.sin_addr), addr_manager_udp.sin_port);

		// 分析接收到的udp设备发现报文，并为止建立json对象
		cJSON *root = PacketAnalyse(recv_buf);

		if (root == NULL)
			printf("PacketAnalyse error\n\r");
		else
		{
			char *out = cJSON_Print(root);
			printf("%s\n", out);
		}

	}

	// 回送tcp连接参数
	send_tcp_params(listen_fd, send_buf, dest_len);

	close(listen_fd);
}

int main(int argc, char **argv)
{
	if(argc<2) {
		printf("\nUsage:\n./agent <ip-address>\n");
		exit(-1);
	}

	code1 = 0;
	code2 = 22;

	memset(&addr_local_udp, 0, sizeof(addr_local_udp));
	addr_local_udp.sin_family = AF_INET;
	addr_local_udp.sin_addr.s_addr = htonl(INADDR_ANY);
	//addr_local_udp.sin_addr.s_addr = inet_addr(argv[1]);
	addr_local_udp.sin_port = htons(AGENT_LISTEN_UDP_BCAST_PORT);
	printf("ip is %s\n", getip(addr_local_udp));

	int dest_len = sizeof(struct sockaddr_in);

	// 接收manager发送的udp发现报文，并进行后续处理
	//
	// 这里的程序结构非常糟糕，控制逻辑嵌套在代码中，每个函数只做一件事，函数
	// 的调用则在控制逻辑中进行组织.
	process_broadcast(dest_len);

	return 0;
}
