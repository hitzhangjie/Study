/**
 * manager program running on control center.
 *
 * step1: 发送udp广播包，目的网络argv[1], 源ip argv[2]，目的端口
 *		  AGENT_LISTEN_UDP_BCAST_PORT
 * step2: 接收来自设备的udp响应，内含tcp连接参数
 * step3: 提取tcp连接参数，发起tcp连接请求
 * step4: 完成manager到agent的tcp连接的建立
 * step5: 发送控制指令到agent.
 */
#include<errno.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<sys/wait.h>
#include<net/if.h>
#include<sys/ioctl.h>
#include"jdcjson.h"
#include <time.h>

// 向指定网络内所有设备的3083端口广播udp发现报文
#define AGENT_LISTEN_UDP_BCAST_PORT 3083
// 向指定设备的3084端口发起tcp连接请求，用于发送控制命令
//#define AGENT_LISTEN_TCP_CMD_PORT 3084

/*
 * run cmd 'ifconfig' to get the right interface's name, it's os relevant
 * which conforms to different nameing schemas.
 */
//#define IFNAME "eth0"
//#define IFNAME "enp0s25"

struct sockaddr_in addr_agent_udp;
struct sockaddr_in addr_agent_tcp;
struct sockaddr_in addr_manager_udp;

/**
 * 从地址结构体中提取ip地址
 *
 * @param sock_in
 * @return 返回提取的ip地址
 */
char * getip(struct sockaddr_in sock_in) {
	char * ip = (char *)malloc(sizeof(char)*16);
	memset(ip, 0, strlen(ip));
	sprintf(ip, "%d.%d.%d.%d", 
		(int)(sock_in.sin_addr.s_addr & 0xFF), 
		(int)((sock_in.sin_addr.s_addr & 0xFF00) >> 8), 
		(int)((sock_in.sin_addr.s_addr & 0xFF0000) >> 16), 
		(int)((sock_in.sin_addr.s_addr & 0xFF000000) >> 24));
	return ip;
}

/**
 * 大端转小端
 * @param A
 * @return 
 */
unsigned int BigtoLittle32(unsigned int A)
{
	unsigned int a, b, c, d, e;
	a = (A & 0x000000ff) << 24;
	b = (A & 0x0000ff00) << 8;
	c = ((A) & 0x00ff0000) >> 8;
	d = ((A) & 0xff000000) >> 24;
	e = a | b | c | d;
	return e;
}

/**
 * 包头信息
 */
typedef struct
{
	unsigned int magic_a;
	unsigned int magic_b;
	unsigned int checksum;	//校验位
	unsigned int len;
} common_header;

/**
 * 小端转大端
 * @param A
 * @return
 */
unsigned int LittletoBig32(unsigned int A)
{
	unsigned int a, b, c, d, e;
	a = (A & 0x000000ff) << 24;
	b = (A & 0x0000ff00) << 8;
	c = ((A) & 0x00ff0000) >> 8;
	d = ((A) & 0xff000000) >> 24;
	e = a | b | c | d;
	return e;
}

/**
 * 建立数据包
 *
 * @param pBuf
 * @param root
 * @param udp_tcp
 *
 * @return 数据包尺寸，字节数量
 */
static int PacketBuild(char *pBuf, cJSON * root, char udp_tcp)
{
	int head = ((udp_tcp == 'U') ? 0x00000055 : 0x00000056);
	common_header *pCommon = (common_header *) pBuf;
	pCommon->magic_a = LittletoBig32(head);
	pCommon->magic_b = LittletoBig32(head);
	char *pData = pBuf + 16;
	char *psJson = cJSON_PrintUnformatted(root);
	int length = strlen(psJson);
	memcpy(pData, psJson, length);
	free(psJson);
	pCommon->len = BigtoLittle32(length + 16);
	int i = 0;
	char sum = 0;
	for (i = 0; i < (length + 16); i++)
		sum += *(pBuf + i);
	pCommon->checksum = LittletoBig32(sum);

	return length + 16;
}

/**
 * 将pBuf中存储的数据，转换成json对象
 *
 * @param pBuf
 * @return 返回创建的json对象
 */
static cJSON *PacketAnalyse(char *pBuf)
{
	common_header *pCommon = (common_header *) pBuf;

	pCommon->magic_a = BigtoLittle32(pCommon->magic_a);
	pCommon->magic_b = BigtoLittle32(pCommon->magic_b);
	pCommon->len = BigtoLittle32(pCommon->len);

	cJSON *pRet = cJSON_Parse(pBuf + 16);

	return pRet;
}


//设备列表的建立与显示
struct clientinfo
{
	char cn[100];
	unsigned long cip;
	unsigned short cport;
} clist[5], *p;


void show_clist(struct clientinfo *p)
{
	for (p = clist; p < clist + 5; p++)
	{
		printf("%s %lu %d ", p->cn, p->cip, p->cport);
	}
	printf("\n");
}

/** 
 * TCP通信的建立与数据处理
 *
 * @param conn_fd 连接socket fd
 */
void process_tcp_packets(int conn_fd)
{
	int recv_num, bytes_sent;
	char send_buf[500] = {0};
	char recv_buf[500] = {0};

	while (1)
	{
		int cmd, per;
		cJSON *root = cJSON_CreateObject();
		if (root == NULL)
			printf("cJSON create failed\n");

		printf("send tcp info start\n");

		printf("please input cmd: ");
		fflush(stdin);
		//scanf("%c", &cmd);
		scanf("%d", &cmd);

		switch (cmd)
		{
		  case 1:
			  printf("please input permission: ");
			  fflush(stdin);
			  //scanf("%c", &per);
			  scanf("%d", &per);
			  switch (per)
			  {
			    case 0:
				    cJSON_AddNumberToObject(root, "cmd", cmd);
				    cJSON_AddNumberToObject(root, "per", per);
				    break;
			    case 1:

				    cJSON_AddNumberToObject(root, "cmd", cmd);
				    cJSON_AddNumberToObject(root, "per", per);
				    int code;
					printf("please input code: ");
					fflush(stdin);
				    scanf("%d", &code);
				    cJSON_AddNumberToObject(root, "code", code);
				    break;
			  }
			  break;
		  case 2:
			  printf("please input permission: ");
			  fflush(stdin);
			  //scanf("%c", &per);
			  scanf("%d", &per);
			  switch (per)
			  {
			    case 0:
				    cJSON_AddNumberToObject(root, "cmd", cmd);
				    cJSON_AddNumberToObject(root, "per", per);
				    break;
			    case 1:
				    cJSON_AddNumberToObject(root, "cmd", cmd);
				    cJSON_AddNumberToObject(root, "per", per);
				    float code;
					printf("please input code: ");
					fflush(stdin);
				    scanf("%f", &code);
				    cJSON_AddNumberToObject(root, "code", code);
				    break;
				default:
					break;
			  }
			  break;
		  case 3:
			  cJSON_AddNumberToObject(root, "cmd", cmd);
			  cJSON_AddNumberToObject(root, "per", per);
			  break;

		  case 4:
			  cJSON_AddNumberToObject(root, "cmd", cmd);
			  cJSON_AddNumberToObject(root, "per", per);
			  char code[100] = {0};
			  printf("please Input name: ");
			  fflush(stdin);
			  scanf("%s", code);
			  cJSON_AddStringToObject(root, "code", code);
			  break;
		  default:
			  break;
		}

		PacketBuild(send_buf, root, 'T');
		bytes_sent = send(conn_fd, send_buf, sizeof(send_buf), 0);
		if (bytes_sent < 0)
		{
			perror("send instruction to agent failed");
			exit(1);
		}
		else
		{
			printf("send instruction to agent success\n");
		}

		printf("begin recv tcp info\n", time(NULL));

		recv_num = recv(conn_fd, recv_buf, sizeof(recv_buf), 0);

		if (recv_num < 0)
		{
			perror("recv tcp info failed");
		}
		else
		{
			cJSON *croot = cJSON_CreateObject();
			if (croot == NULL)
				printf("cJSON create failed\n");
			PacketAnalyse(recv_buf);
			int ccmd;
			ccmd = cJSON_GetObjectItem(root, "cmd")->valueint;
			//解析json中的string
			int ccodea;
			float ccodeb;
			char *ccodec;
			switch (ccmd)
			{
			  case 1:
				  ccodea = cJSON_GetObjectItem(root, "code")->valueint;
				  printf("ccmd=%d  code = %d\n", (char)ccmd, ccodea);
				  break;
			  case 2:
				  ccodeb = cJSON_GetObjectItem(root, "code")->valuedouble;
				  printf("ccmd=%d  code = %f\n", (char)ccmd, ccodeb);
				  break;
			  case 3:
				  ccodec = cJSON_GetObjectItem(root, "code")->valuestring;
				  printf("ccmd=%d  code = %s\n", (char)ccmd, ccodec);
				  break;
			  default:
				  break;
			}

		}
	}
}

/**
 * @see docs why does agent send tcp port to manager ?
 *           let manager setup listening tcp port or let manager connect to
 *           agent:port ? make it clear.
 *           now i will conforms to ChangGe's design, i.e, the latter
 *           providing.
 * @deprecated initiate tcp conn establishment request to agent
 */
void setup_tcp_listen(struct sockaddr_in addr_manager_udp)
{
	int listen_fd = socket(AF_INET, SOCK_STREAM, 0);
	if (listen_fd < 0)
	{
		perror("alloc tcp socket failed");
		exit(1);
	}
	else
	{
		printf("alloc tcp sock successful\n");
	}

//	if (bind(listen_fd, (struct sockaddr *)&addr_agent_udp, sizeof(struct sockaddr_in)) < 0)
	
	if (bind(listen_fd, (struct sockaddr *)&addr_manager_udp, sizeof(struct sockaddr_in)) < 0)
	{
		perror("bind tcp socket failed");
		exit(1);
	}
	else
		printf("bind tcp socket success\n");


	// listen(fd, backlog), let 'backlog' bigger to avoid connection refused
	// error.
	if (listen(listen_fd, 100) < 0)
	{
		perror("manager listen failed");
		exit(1);
	}
	else
	{
		printf("manager listen successful\n");
	}

	while (1)
	{
		//conn_fd = accept(listen_fd, (struct sockaddr *)&addr_manager_udp,
		//&client_len);
		//conn_fd = accept
		//		(listen_fd, (struct sockaddr *)&addr_manager_udp, NULL);
		socklen_t sock_len = sizeof(addr_agent_udp);
		//printf("wait conn request come\n");
		int conn_fd = 
			accept(listen_fd, (struct sockaddr *)&addr_agent_udp, &sock_len);
		printf("one conn establish\n");

		if (conn_fd < 0)
		{
			perror("accept conn from agent failed");
			//printf("accept(%d)\n", errno);
			exit(-1);
		}
		else {
			printf("accept conn from agent successful");
		}

		printf("ready to fork\n");
		// why fork 2nd times?.
		//
		// one kind devices has too many devices, which share same manger
		// instruct control port.
		// why not use multi-thread ? maybe multi-process is easier when no
		// IPC is required.
		//
		// did you know the fact fork() 2 times or more will make process lose
		// then control 
		pid_t pid = fork();
		if (pid == 0)
		{
			while (1)
			{
				process_tcp_packets(conn_fd);
				sleep(1);
			}
		}
		//printf("manager sleep 1s\n");
		sleep(1);
	}
}

/**
 * 处理tcp请求
 *
 * @param addr_agent_tcp 管理站地址
 */
void process_tcp(struct sockaddr_in addr_agent_tcp)
{
	int conn_fd, result;

	conn_fd = socket(AF_INET, SOCK_STREAM, 0);
	if (conn_fd < 0)
	{
		perror("申请tcp socket失败");
		exit(1);
	}
	else
	{
		printf("申请tcp socket成功\n");
	}

	// 建立连接
	result = connect(
			conn_fd, (struct sockaddr *)&addr_agent_tcp, sizeof(addr_agent_tcp));

	if (result < 0)
	{
		perror("tcp连接失败");
		exit(-1);
	}
	else
	{
		printf("tcp连接成功\n");
		addr_manager_udp = addr_agent_tcp;
	}

	while (1)
	{
		process_tcp_packets(conn_fd);
		sleep(1);
	}
}

/**
 * 接收agent回送的tcp连接参数，并建立与agent的tcp连接发送控制命令
 *
 * @param bcast_fd 用于广播的udp socket fd
 */
void process_recved_params(int bcast_fd)
{
	// 一次广播，接收多个agent的响应，所以使用循环，等待agent回送tcp连接参数
	while(1) {
		char recv_buf[500] = {0};
		socklen_t len = sizeof(addr_agent_udp);
		int recv_num = recvfrom(bcast_fd, recv_buf, sizeof(recv_buf), 0,
				(struct sockaddr *)&addr_agent_udp, &len);

		//int recv_num = recv(bcast_fd, recv_buf, sizeof(recv_buf), 0);
		addr_agent_tcp.sin_family = AF_INET;
		addr_agent_tcp.sin_addr.s_addr = addr_agent_udp.sin_addr.s_addr;
		//addr_agent_tcp.sin_port = htons(AGENT_LISTEN_TCP_CMD_PORT);

		if(recv_num < 0) {
			perror("读取tcp连接参数失败");
			exit(-1);
		}
		else
			printf("读取tcp连接参数成功\n");

		int i;
		for (i = 0; i < recv_num; i++) {
			printf("%x", recv_buf[i]);
		}
		printf("\n");

		// 解析接收的tcp连接参数信息，并建立成json对象
		cJSON *root = PacketAnalyse(recv_buf);
		if (root == NULL)
			printf("PacketAnalyse error\n\r");

		// 更新tcp端口信息
		addr_agent_tcp.sin_port = 
			htons(cJSON_GetObjectItem(root, "port")->valueint);
		printf("待连接agent信息，ip: %s，port: %d\n", 
				getip(addr_agent_udp),
				cJSON_GetObjectItem(root, "port")->valueint);

		// 发起tcp连接请求
		int conn_fd = socket(AF_INET, SOCK_STREAM, 0);
		if(conn_fd<0) {
			perror("申请tcp socket失败");
			exit(-1);
		}
		else
			printf("申请tcp socket成功\n");

		sleep(1);
		// 建立连接
		int result = connect(
				conn_fd, (struct sockaddr *)&addr_agent_tcp, sizeof(addr_agent_tcp));
		if(result<0) {
			perror("建立到agent的tcp连接，连接失败");
			exit(-1);
		}
		else
			printf("建立到agent的tcp连接，连接成功\n");

		// 子进程处理后续连接请求
		pid_t pid = fork();
		if(pid==0) {
			while (1)
			{
				process_tcp_packets(conn_fd);
				sleep(1);
			}
		}

		sleep(1);
	}
}

/**
 * 发送udp设备发现数据包
 *
 * @param send_buf 待发送数据缓存
 * @param data_len 待发送数据长度
 */
void send_broadcast(char send_buf[], int data_len)
{
	int bcast_fd = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
	//bcast_fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (bcast_fd < 0)
	{
		perror("申请udp socket失败");
		exit(1);
	}
	else
		printf("申请udp socket成功\n");

	// 激活udp socket广播模式
	int optval = 1;
	int mb = setsockopt(
			bcast_fd, SOL_SOCKET, SO_BROADCAST, &optval, sizeof(int));
	if (mb < 0)
	{
		perror("激活广播模式失败");
		exit(1);
	}
	else
		printf("激活广播模式成功\n");

	// 指定广播地址，并发送udp设备发现报文
	printf("dest ip is: %s\n", getip(addr_agent_udp));
	int bytes_sent = sendto(bcast_fd, send_buf, data_len, 0, 
				(struct sockaddr *)&addr_agent_udp, sizeof(struct sockaddr_in));

	if (bytes_sent < 0)
	{
		perror("发送udp设备发现报文，发送失败");
		exit(-1);
	}
	else
	{
		printf("发送udp设备发现报文，发送成功:%s\n", send_buf);
		int a = 0;
		for (a = 0; a < 50; a++) {
			printf("%x", send_buf[a]);
		}
		printf("\n");
	}

	sleep(1);

	// 接收agent回送的tcp连接参数，并建立与agent的tcp连接参数
	process_recved_params(bcast_fd);
	close(bcast_fd);
}

void printfff(int s, char *buf)
{
//int s;
	for (s = 0; s < 100; s++)
		printf("%x", buf[s]);
}


/**
 * main function
 *
 * @param argc
 * @param argv argv[1]代表广播地址
 *
 * @return
 */
int main(int argc, char **argv)
{
	if(argc<3) {
		printf("\nUsage:\n./manager <broadcast-address> <ip-address>\n");
		exit(-1);
	}

	// 设置广播地址
	memset(&addr_agent_udp, 0, sizeof(struct sockaddr_in));
	addr_agent_udp.sin_family = AF_INET;
	addr_agent_udp.sin_port = htons(AGENT_LISTEN_UDP_BCAST_PORT);
	addr_agent_udp.sin_addr.s_addr = inet_addr(argv[1]);

	printf("管理站manager ip地址: %s\n", argv[2]);

	cJSON *root = cJSON_CreateObject();
	if (root == NULL)
		printf("cJSON create failed\n");
	cJSON_AddStringToObject(root, "data", "BRDS");
	//char *out = cJSON_Print(root);
	//printf("%s\n",out);           
	
	// 建立并发送udp广播分组，即建立并发送设备发现报文
	unsigned char send_buf[100] = { 0 };
	int data_len = PacketBuild(send_buf, root, 'U');
	send_broadcast(send_buf, data_len);

	return 0;
}
